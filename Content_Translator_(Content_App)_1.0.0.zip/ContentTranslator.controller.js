﻿
angular.module("umbraco")
    .controller("My.ContentTranslator", function ($http, $scope) {

        var vm = this;
        vm.IsTestMode = false;
        vm.Loading = false;

        var clipboard = new ClipboardJS('#ContentTranslator_CopyToClipboard');

        $http({
            method: "GET",
            url: "/Umbraco/ContentTranslator/ContentTranslator/IsTestMode"
        }).then(function mySuccess(response) {
            vm.IsTestMode = response.data;
        });

        $scope.TranslateContent = function () {

            vm.Loading = true;
            vm.ErrorMessage = '';
            var url = "/Umbraco/ContentTranslator/ContentTranslator/TranslateContent";

            $http({
                method: "POST",
                url: url,
                data: {
                    Source: vm.Source,
                    Target: vm.Target,
                    OrigionalText: vm.OrigionalText
                },
            }).then(function successCallback(response) {
                vm.Loading = false;
                var data = angular.fromJson(response.data);
                vm.TranslatedText = data.TranslatedText;
                vm.ErrorMessage = data.ErrorMessage;
            }, function errorCallback() {
                vm.Loading = false;
                vm.ErrorMessage = "Sorry there was a generic error. If this continues to happen please notify support for a fix.";
            });
        };
    });
